<div id="sidebar-collapse" class="col-sm-3 col-lg-2 sidebar">
      <div class="profile-sidebar">
        <div class="profile-userpic">
          <img src="foto/suratku.png" class="img-responsive" alt="" />
        </div>
        <div class="profile-usertitle">
          <div class="profile-usertitle-name">Dinda </div>
          <div class="profile-usertitle-name">Valentina</div>
        </div>
        <div class="clear"></div>
      </div>
      <div class="divider"></div>
      <!-- <form role="search">
        <div class="form-group">
          <input type="text" class="form-control" placeholder="Search" />
        </div>
      </form> -->
      <ul class="nav menu">
        <li class="nav-item">
          <a href="index.php"><em class="fa fa-archive">&nbsp;</em> Arsip</a>
        </li>
        <li class="nav-item">
          <a href="about.php"><em class="fa fa-exclamation-circle">&nbsp;</em> About</a>
        </li>
        <!-- <li class="parent">
          <a data-toggle="collapse" href="#sub-item-1">
            <em class="fa fa-cutlery">&nbsp;</em> Menu <span data-toggle="collapse" href="#sub-item-1" class="icon pull-right"><em class="fa fa-plus"></em></span>
          </a>
          <ul class="children collapse" id="sub-item-1">
            <li>
              <a class="" href="menu.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tampil Menu </a>
            </li>
            <li>
              <a class="" href="create-menu.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tambah Menu </a>
            </li>
          </ul>
        </li>
        <li class="parent">
          <a data-toggle="collapse" href="#sub-item-2">
            <em class="fa fa-id-card">&nbsp;</em> Pegawai <span data-toggle="collapse" href="#sub-item-2" class="icon pull-right"><em class="fa fa-plus"></em></span>
          </a>
          <ul class="children collapse" id="sub-item-2">
            <li>
              <a class="" href="pegawai.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tampil Pegawai </a>
            </li>
            <li>
              <a class="" href="create-pegawai.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tambah Pegawai </a>
            </li>
          </ul>
        </li>
        <li class="parent">
          <a data-toggle="collapse" href="#sub-item-3">
            <em class="fa fa-user">&nbsp;</em> Pembeli <span data-toggle="collapse" href="#sub-item-3" class="icon pull-right"><em class="fa fa-plus"></em></span>
          </a>
          <ul class="children collapse" id="sub-item-3">
            <li>
              <a class="" href="pembeli.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tampil Pembeli </a>
            </li>
            <li>
              <a class="" href="create-pembeli.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tambah Pembeli </a>
            </li>
          </ul>
        </li>
        <li class="parent">
          <a data-toggle="collapse" href="#sub-item-4">
            <em class="fa fa-shopping-cart">&nbsp;</em> Transaksi <span data-toggle="collapse" href="#sub-item-4" class="icon pull-right"><em class="fa fa-plus"></em></span>
          </a>
          <ul class="children collapse" id="sub-item-4">
            <li>
              <a class="" href="transaksi.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tampil Transaksi </a>
            </li>
            <li>
              <a class="" href="create-transaksi.php"> <span class="fa fa-arrow-right">&nbsp;</span> Tambah Transaksi </a>
            </li>
          </ul>
        </li>
        <li>
          <a href="login.html"><em class="fa fa-power-off">&nbsp;</em> Logout</a>
        </li> -->
      </ul>
    </div>
    <!--/.sidebar-->